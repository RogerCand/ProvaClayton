package automatizado.testes;

import automatizado.pageObject.ProdutoPO;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class ProdutoTest extends BaseTest{
    private static ProdutoPO ProdutoPage;

    @BeforeClass
    public static void prepararTestes(){
        ProdutoPage =new ProdutoPO(driver);
    }

    @Test
    public void TC01_naoDeveFazerOCadastroComNenhumCampoVazio(){

//        não deve salvar o produto sem nenhum campo preenchido

        ProdutoPage.buttonAdcionar.click();
        ProdutoPage.buttonAdcionar.click();

        ProdutoPage.inputCodigo.sendKeys("");
        ProdutoPage.inputNome.sendKeys("");
        ProdutoPage.inputQuantidade.sendKeys("");
        ProdutoPage.inputValor.sendKeys("");
        ProdutoPage.inputData.sendKeys("");

        ProdutoPage.buttonSalvar.click();

        String mensagem = ProdutoPage.obterMensagem();

        assertEquals(mensagem,"Todos os campos são obrigatórios para o cadastro!");

    }


    @Test
    public void TC02_naoDeveFazerOCadastroComCodigoVazio(){

//       não deve salvar o produto sem o campo de codigo estar preenchido

        ProdutoPage.buttonAdcionar.click();
        ProdutoPage.buttonAdcionar.click();

        ProdutoPage.inputCodigo.sendKeys("");
        ProdutoPage.inputNome.sendKeys("Roger");
        ProdutoPage.inputQuantidade.sendKeys("1");
        ProdutoPage.inputValor.sendKeys("R$1.000.000.00");
        ProdutoPage.inputData.sendKeys("23/11/2001");

        ProdutoPage.buttonSalvar.click();

        String mensagem = ProdutoPage.obterMensagem();

        assertEquals(mensagem,"Todos os campos são obrigatórios para o cadastro!");

    }


    @Test
    public void TC03_naoDeveFazerOCadastroComNomeEValorVazio(){

//        não deixar salvar o produto sem o campo de nome e valor estar preenchido

        ProdutoPage.buttonAdcionar.click();
        ProdutoPage.buttonAdcionar.click();

        ProdutoPage.inputCodigo.sendKeys("1");
        ProdutoPage.inputNome.sendKeys("");
        ProdutoPage.inputQuantidade.sendKeys("1");
        ProdutoPage.inputValor.sendKeys("");
        ProdutoPage.inputData.sendKeys("23/11/2001");

        ProdutoPage.buttonSalvar.click();

        String mensagem = ProdutoPage.obterMensagem();

        assertEquals(mensagem,"Todos os campos são obrigatórios para o cadastro!");

    }



}