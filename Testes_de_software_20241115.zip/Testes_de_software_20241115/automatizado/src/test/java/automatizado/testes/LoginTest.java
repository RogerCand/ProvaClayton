//package automatizado.testes;
//
//
//
//import automatizado.pageObject.LoginPO;
//import org.junit.Assert;
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//import static org.junit.Assert.assertEquals;
//
//
//public class LoginTest extends BaseTest{
//
//    private static LoginPO LogInPage;
//
//    @BeforeClass
//    public static void prepararTestes() {
//        LogInPage = new LoginPO(driver);
//        driver.get("file:///C:/Users/36129382023.2n/Downloads/sistema/login.html");
//    }
//
//
////    @Test
////    public void TC001_naoDeveLogarNoSistemacComEmailESenhaVazio(){
////        LogInPage.inputEmail.sendKeys("");
////        LogInPage.inputsenha.sendKeys("");
////        LogInPage.buttomEntrar.click();
////
////        String mensagem = LogInPage.obterMensagem();
////
////        assertEquals(mensagem, "informe usuario e senha e os campos nao podem ser brancos");
////    }
//
//    @Test
//    public void TC002_naoDeveLogarNoSistemacComEmailIncorretoESenhaVazio(){
//        LogInPage.inputEmail.sendKeys("admin@admin.com");
//        LogInPage.inputsenha.sendKeys("admin@123");
//        LogInPage.buttomEntrar.click();
//
//        String mensagem = LogInPage.obterMensagem();
//
//        assertEquals(mensagem, "Informe usuário e senha, os campos não podem ser brancos.");
//    }
//
//}
//
